from django.apps import AppConfig


class TesteConfig(AppConfig):
    name = 'sinfApi'
