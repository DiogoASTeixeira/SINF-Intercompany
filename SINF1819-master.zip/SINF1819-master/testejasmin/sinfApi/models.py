from django.core import serializers
from django.db import models


# Create your models here.
class Product(models.Model):
    name = models.TextField()
    description = models.TextField()

    def __str__(self):
        return serializers.serialize('json', [self])

    class Meta:
        db_table = "product"


class OrderRequest(models.Model):
    product_id = models.TextField()
    status = models.TextField()

    def __str__(self):
        return serializers.serialize('json', [self])

    class Meta:
        db_table = "order_request"
