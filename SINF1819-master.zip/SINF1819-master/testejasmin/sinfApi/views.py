import json

import requests
from django.http import HttpResponse
from requests import Response
from rest_framework.utils import json
from rest_framework.views import APIView
from sinfApi.models import OrderRequest

# Create your views here.

JASMIN_URL = "my.jasminsoftware.com/api"

SUPP_CLI_ID = "MFN12345"
SUPP_SECRET = "899917e8-2934-4377-88fa-d6d1b1813331"
SUPP_TOKEN = ""
SUPP_TENANT = "226693"
SUPP_ORG = "226693-0001"

CUST_CLI_ID = "VORTEN12345"
CUST_SECRET = "1d726b59-11ea-48a5-a782-4dac3a172497"
CUST_TOKEN = ""
CUST_TENANT = "227013"
CUST_ORG = "227013-0001"


class Index(APIView):
    def get(self, request):
        # p = Product(name="XBOX 720",description="It doesn't exist")
        # p.save()
        # b = Product.objects.all()

        response = requests.post("https://my.jasminsoftware.com/api/227013/227013-0001/salesCore/customerParties",
                                 headers={
                                     'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjBCMjI3OTVEMzcyMzQ2NDIwOUE2MDIxQUQ4OUE1OTdFRjE0OTZEODAiLCJ0eXAiOiJKV1QiLCJ4NXQiOiJDeUo1WFRjalJrSUpwZ0lhMkpwWmZ2RkpiWUEifQ.eyJuYmYiOjE1NzUwMjA5MDYsImV4cCI6MTU3NTAzNTMwNiwiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS5wcmltYXZlcmFic3MuY29tIiwiYXVkIjpbImh0dHBzOi8vaWRlbnRpdHkucHJpbWF2ZXJhYnNzLmNvbS9yZXNvdXJjZXMiLCJqYXNtaW4iXSwiY2xpZW50X2lkIjoiVk9SVEVOMTIzNDUiLCJzY29wZSI6WyJhcHBsaWNhdGlvbiJdfQ.Ps8Q9gyBuYXeWqWgb0Z3lXVkV0SUXi06VFewQecybNSrD_TvdDiuZr01cSM-0Dso4xEdjRbSTMOIi3H8Wf8z22YoMIbRQXU64r0BSkXDOXh1HtAhX7H3cF5rxM2FPdPD6I9PLHIpt-e5RaBUwRmu1HuTI_H-NkHfomxD0ROKWvFE9M569fUPECR82QAPn9RFuSWMex_TVdYk8DCpafXHcWOM1IkIRaEpa9p1NvbtLTIvSDCSks-INCRjF_-iycNdPHtq_O4pjIpbw9En2kPwouoIvfQHE4vd-Be4xgrMvVjUdU5Q5muHsCjs_B4KdazEyz_Bitt5wJlVHlg6QI3eUQ',
                                     'Content-type': 'application/json'
                                 }, json={
                "name": "Stor Incompetente",
                "isExternallyManaged": "false",
                "currency": "EUR",
                "isPerson": "true",
                "country": "BR"
            }, )

        print(response)

        return HttpResponse(response, content_type="application/json")


class Request(APIView):
    def post(self, request):
        body = json.loads(request.body)
        print(body['product_id'])
        new = OrderRequest(product_id=body['product_id'])
        new.save()

        return HttpResponse('')


class ProductInfo(APIView):
    def get(self, request):
        response = requests.get(
            "https://" + JASMIN_URL + "/" + SUPP_TENANT + "/" + SUPP_ORG + "/salesCore/salesItems",
            headers={
                'Authorization': SUPP_TOKEN,
                'Content-Type': 'application/json'
            })
        #content = json.loads(response.text)

        dict = []

        print(response.text)

        data = response.json()


        for item in data:
            print(item['itemKey'])
            temp_dict = {
                'name': item['itemKey'],
                'price': item['priceListLines'][0]['priceAmount']['amount'],
                'desc': item['description'],
            }
            dict.append(temp_dict)

        print(dict)
        return HttpResponse(status=200)


class Auth(APIView):
    def get(self, request):
        response = requests.post("https://identity.primaverabss.com/connect/token",
                                 headers={
                                     'Content-type': 'application/x-www-form-urlencoded'
                                 }, data={
                "grant_type": "client_credentials",
                "client_id": CUST_CLI_ID,
                "client_secret": CUST_SECRET,
                "scope": "application"
            }, )

        content = json.loads(response.text)
        global CUST_TOKEN
        CUST_TOKEN = content['token_type'] + " " + content["access_token"]

        print(response)

        response = requests.post("https://identity.primaverabss.com/connect/token",
                                 headers={
                                     'Content-type': 'application/x-www-form-urlencoded'
                                 }, data={
                "grant_type": "client_credentials",
                "client_id": SUPP_CLI_ID,
                "client_secret": SUPP_SECRET,
                "scope": "application"
            }, )

        content = json.loads(response.text)
        global SUPP_TOKEN
        SUPP_TOKEN = content['token_type'] + " " + content["access_token"]

        return HttpResponse(response, content_type="application/json")
