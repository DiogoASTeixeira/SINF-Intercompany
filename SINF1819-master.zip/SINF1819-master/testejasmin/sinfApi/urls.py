from django.urls import path

from . import views

urlpatterns = [
    path('index', views.Index.as_view()),
    path('order-request', views.Request.as_view()),
    path('login', views.Auth.as_view()),
    path('products', views.ProductInfo.as_view())
]